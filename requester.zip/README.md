# Raw request sender

Python utility that reads raw HTTP requests from `requests/*.txt` and replays them on a timer.

## Quick start
- Install deps: `python3 -m venv .venv && source .venv/bin/activate && pip install -r requirements.txt`
- Put your raw requests into `requests/*.txt` using the standard format (request line, headers, blank line, body). Files starting with `example` are ignored until you rename them.
- Add proxies to `proxies.txt` (any common format: `ip:port`, `user:pass@ip:port`, `http://..`, `socks5://..`). Empty file → direct mode with a 10s warning delay.
- Adjust `config.py` if you need a different interval, scheme, or host override.
- Add placeholders to `placeholders/{name}.txt` (or `placeholders/{name}`) with one value per line; use `{name}` anywhere in the raw request to substitute values. Blank lines and lines starting with `#` are ignored. Rotation is set by `PLACEHOLDER_ROTATION` in `config.py` (`sequential` or `random`).
- Run the loop: `python requester.py` or `python -m requester` (force direct mode with `--direct` to skip the 10s delay).
- To dump responses, use `--response` (prints to console) or `--response out.txt` (writes to `responses/out.txt`, creating the folder if needed).

Notes:
- The script strips `Content-Length` before sending because the `requests` library sets it automatically.
- If the request line already contains a full URL it will be used as-is; otherwise the URL is built from `SCHEME` + host + path.
- Requests are sent in batches every `INTERVAL_SECONDS` (default: 30); stop with Ctrl+C.
- Proxy health is checked on each request; if a proxy fails it is dropped and the next proxy (or direct) is used automatically.
- Placeholder values rotate per request; all occurrences of the same `{name}` in a single request use the same chosen value.
- Logs are colorized for readability. Responses are emitted as raw blocks (status, headers, body) when `--response` is enabled.
