import argparse
import logging
import random
import re
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional

import requests
from colorama import Fore, Style, init as colorama_init

import config


colorama_init(autoreset=True)


class ColorFormatter(logging.Formatter):
    COLORS = {
        logging.DEBUG: Fore.CYAN,
        logging.INFO: Fore.GREEN,
        logging.WARNING: Fore.YELLOW,
        logging.ERROR: Fore.RED,
        logging.CRITICAL: Fore.RED + Style.BRIGHT,
    }

    def format(self, record: logging.LogRecord) -> str:  # type: ignore[override]
        color = self.COLORS.get(record.levelno, "")
        reset = Style.RESET_ALL
        time_str = self.formatTime(record, "%H:%M:%S")
        level = f"{record.levelname:<8}"
        msg = record.getMessage()
        return f"{Fore.WHITE}{time_str}{reset} {color}{level}{reset} {msg}"


handler = logging.StreamHandler()
handler.setFormatter(ColorFormatter())
logging.basicConfig(level=logging.INFO, handlers=[handler])


@dataclass
class ParsedRequest:
    method: str
    path: str
    headers: Dict[str, str]
    body: str


class ProxyPool:
    def __init__(self, proxies: List[str], ignore_proxies: bool = False) -> None:
        self._proxies = proxies
        self._index = 0
        self.ignore_proxies = ignore_proxies
        self._warned_empty = not proxies

    def has_proxies(self) -> bool:
        return (not self.ignore_proxies) and bool(self._proxies)

    def next_proxy(self) -> Optional[str]:
        if not self.has_proxies():
            return None
        proxy = self._proxies[self._index % len(self._proxies)]
        self._index = (self._index + 1) % len(self._proxies)
        return proxy

    def mark_bad(self, proxy: Optional[str]) -> None:
        if proxy is None:
            return
        try:
            idx = self._proxies.index(proxy)
        except ValueError:
            return
        self._proxies.pop(idx)
        if self._index > idx:
            self._index -= 1
        if not self._proxies and not self._warned_empty:
            logging.warning("Proxy list is empty, switching to direct.")
            self._warned_empty = True


class PlaceholderResolver:
    pattern = re.compile(r"\{([A-Za-z0-9_\-]+)\}")

    def __init__(self, folder: Path, rotation: str = "sequential") -> None:
        self.folder = folder
        self.rotation = rotation.lower()
        self.values: Dict[str, List[str]] = {}
        self.indexes: Dict[str, int] = {}
        folder.mkdir(parents=True, exist_ok=True)
        if self.rotation not in {"sequential", "random"}:
            logging.warning(
                "Unknown placeholder rotation '%s', falling back to 'sequential'",
                rotation,
            )
            self.rotation = "sequential"

    def _path_for(self, name: str) -> Path:
        direct = self.folder / name
        with_txt = self.folder / f"{name}.txt"
        if direct.exists():
            return direct
        if with_txt.exists():
            return with_txt
        return direct

    def _ensure_loaded(self, name: str) -> None:
        if name in self.values:
            return
        path = self._path_for(name)
        if not path.exists():
            raise ValueError(f"Placeholder '{name}' not found (expected {path} or {path}.txt)")
        lines = [
            line.strip()
            for line in path.read_text(encoding="utf-8").splitlines()
            if line.strip() and not line.strip().startswith("#")
        ]
        if not lines:
            raise ValueError(f"Placeholder '{name}' has no values in {path}")
        self.values[name] = lines
        self.indexes.setdefault(name, 0)

    def _next_value(self, name: str) -> str:
        self._ensure_loaded(name)
        vals = self.values[name]
        if self.rotation == "random":
            return random.choice(vals)
        idx = self.indexes.get(name, 0) % len(vals)
        self.indexes[name] = (idx + 1) % len(vals)
        return vals[idx]

    def replace(self, text: str) -> str:
        names = set(self.pattern.findall(text))
        if not names:
            return text
        replacements = {name: self._next_value(name) for name in names}
        return self.pattern.sub(lambda m: replacements[m.group(1)], text)


def parse_raw_request(raw_text: str) -> ParsedRequest:
    """Convert raw HTTP text into a ParsedRequest object."""
    if not raw_text.strip():
        raise ValueError("request text is empty")

    head, body = _split_head_and_body(raw_text)
    head_lines = head.splitlines()
    if not head_lines:
        raise ValueError("missing request line")

    try:
        method, path, _ = head_lines[0].strip().split()
    except ValueError as exc:  # not enough values to unpack
        raise ValueError(f"cannot parse request line: {head_lines[0]}") from exc

    headers: Dict[str, str] = {}
    for line in head_lines[1:]:
        if not line.strip():
            continue
        if ":" not in line:
            raise ValueError(f"invalid header format: {line}")
        name, value = line.split(":", 1)
        headers[name.strip()] = value.strip()

    return ParsedRequest(method=method, path=path, headers=headers, body=body)


def _split_head_and_body(raw_text: str) -> tuple[str, str]:
    parts = re.split(r"\r?\n\r?\n", raw_text, maxsplit=1)
    head = parts[0].replace("\r", "")
    body = parts[1] if len(parts) > 1 else ""
    return head, body


def iter_request_files() -> Iterable[Path]:
    folder = Path(config.REQUESTS_DIR)
    folder.mkdir(parents=True, exist_ok=True)
    for path in sorted(folder.glob("*.txt")):
        # Ignore example files unless the user renames them.
        if path.name.lower().startswith("example"):
            continue
        yield path


def format_response_block(response: requests.Response) -> str:
    status_line = f"{response.status_code} {response.reason} {response.url}"
    headers = "\n".join(f"{k}: {v}" for k, v in response.headers.items())
    body = response.text
    return "\n".join(
        [
            "=" * 70,
            status_line,
            headers,
            "",
            body,
            "=" * 70,
            "",
        ]
    )


class ResponseSink:
    def __init__(self, target: Optional[str]) -> None:
        """
        target:
            None       -> disabled
            True/""    -> console dump
            "file"     -> append to responses/<file> (or absolute path)
        """
        if target is None:
            self.mode = "off"
            self.path = None
        elif target is True:
            self.mode = "console"
            self.path = None
        else:
            dest = Path(target)
            if not dest.is_absolute():
                dest = Path(config.RESPONSES_DIR) / dest
            dest.parent.mkdir(parents=True, exist_ok=True)
            self.mode = "file"
            self.path = dest

    def enabled(self) -> bool:
        return self.mode != "off"

    def write(self, response: requests.Response) -> None:
        block = format_response_block(response)
        if self.mode == "console":
            print(block)
        elif self.mode == "file" and self.path:
            with self.path.open("a", encoding="utf-8") as fh:
                fh.write(block)


def send_request(
    parsed: ParsedRequest,
    session: requests.Session,
    proxies: Optional[Dict[str, str]] = None,
) -> requests.Response:
    headers = {
        key: value
        for key, value in parsed.headers.items()
        if key.lower() not in config.SKIP_HEADERS
    }

    if parsed.path.lower().startswith(("http://", "https://")):
        url = parsed.path
    else:
        host = config.DEFAULT_HOST or parsed.headers.get("Host")
        if not host:
            raise ValueError("Host header is missing and DEFAULT_HOST is not set")
        url = f"{config.SCHEME}://{host}{parsed.path}"
    response = session.request(
        parsed.method,
        url,
        headers=headers,
        data=parsed.body,
        verify=config.VERIFY_TLS,
        timeout=config.TIMEOUT_SECONDS,
        proxies=proxies,
    )
    return response


def normalize_proxy_line(line: str) -> Optional[str]:
    raw = line.strip()
    if not raw or raw.startswith("#"):
        return None

    token = raw.split()[0]

    if "://" in token:
        return token
    if "@" in token:
        return f"http://{token}"

    parts = token.split(":")
    if len(parts) >= 4:
        host, port, user, password = parts[0], parts[1], parts[2], parts[3]
        return f"http://{user}:{password}@{host}:{port}"
    if len(parts) >= 2:
        host, port = parts[0], parts[1]
        return f"http://{host}:{port}"

    return f"http://{token}"


def load_proxies(path: Path) -> List[str]:
    if not path.exists():
        logging.warning("Proxy file not found: %s", path)
        return []

    proxies: List[str] = []
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        normalized = normalize_proxy_line(raw_line)
        if normalized:
            proxies.append(normalized)
    return proxies


def warn_no_proxies(delay: bool, source: Path, direct_flag: bool) -> None:
    banner = "\n".join(
        [
            "=" * 70,
            "  NO PROXIES FOUND — RUNNING DIRECT",
            f"  File: {source}",
            "  Add proxies or use --direct to skip the startup delay.",
            "=" * 70,
        ]
    )
    logging.warning(banner)
    if delay:
        logging.warning("Starting in 10 seconds because proxies are missing...")
        time.sleep(10)
    elif direct_flag:
        logging.warning("--direct flag: running direct with no delay.")


def send_with_proxy_failover(
    parsed: ParsedRequest, session: requests.Session, pool: ProxyPool
) -> requests.Response:
    while True:
        proxy_url = pool.next_proxy()
        proxies = {"http": proxy_url, "https": proxy_url} if proxy_url else None
        try:
            response = send_request(parsed, session, proxies=proxies)
            mode = f"proxy={proxy_url}" if proxy_url else "direct"
            logging.info(
                "%s %s -> %s (%s bytes) via %s",
                parsed.method,
                parsed.path,
                response.status_code,
                len(response.content),
                mode,
            )
            return response
        except requests.RequestException as exc:
            if proxy_url:
                logging.error("Proxy failed (%s), removing. Error: %s", proxy_url, exc)
                pool.mark_bad(proxy_url)
                continue
            raise
        except Exception:
            raise


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--direct",
        action="store_true",
        help="Ignore proxies.txt and send directly.",
    )
    parser.add_argument(
        "--proxy-file",
        default=config.PROXIES_FILE,
        type=Path,
        help="Path to proxy list file (default: config.PROXIES_FILE).",
    )
    parser.add_argument(
        "--response",
        nargs="?",
        const=True,
        metavar="FILE",
        help="Dump responses. Without FILE -> print to console. With FILE -> append to responses/FILE (or abs path).",
    )
    return parser.parse_args()


def run_loop(args: argparse.Namespace) -> None:
    session = requests.Session()

    proxies = [] if args.direct else load_proxies(Path(args.proxy_file))
    if args.direct and proxies:
        logging.info(
            "--direct включен: игнорируем %s прокси из %s",
            len(proxies),
            args.proxy_file,
        )
        proxies = []

    pool = ProxyPool(proxies, ignore_proxies=args.direct)
    if pool.has_proxies():
        logging.info("Loaded proxies: %s (from %s)", len(proxies), args.proxy_file)
    else:
        warn_no_proxies(delay=not args.direct, source=Path(args.proxy_file), direct_flag=args.direct)

    logging.info("Starting sender. Reading from %s", config.REQUESTS_DIR)
    resolver = PlaceholderResolver(
        folder=Path(config.PLACEHOLDERS_DIR),
        rotation=config.PLACEHOLDER_ROTATION,
    )
    response_sink = ResponseSink(args.response)
    if response_sink.enabled():
        mode = "console" if response_sink.mode == "console" else f"file={response_sink.path}"
        logging.info("Response dump enabled (%s)", mode)

    try:
        while True:
            files = list(iter_request_files())
            if not files:
                logging.warning("No *.txt request files found in %s, stopping.", config.REQUESTS_DIR)
                break

            for path in files:
                try:
                    raw_text = path.read_text(encoding="utf-8")
                    raw_text = resolver.replace(raw_text)
                    parsed = parse_raw_request(raw_text)
                    response = send_with_proxy_failover(parsed, session, pool)
                    if response_sink.enabled():
                        response_sink.write(response)
                except Exception as exc:
                    logging.error("Failed to send %s: %s", path.name, exc)

            time.sleep(config.INTERVAL_SECONDS)
    except KeyboardInterrupt:
        logging.info("Interrupted with Ctrl+C, exiting cleanly.")
    finally:
        session.close()


def main() -> None:
    run_loop(parse_args())


if __name__ == "__main__":
    main()
